#!/bin/bash
systemctl stop pipeline-campaign.service
docker stop -t 5 bench-browser bench-dispatcher bench-search bench-playback >/dev/null 2>&1
cd /opt/vindex-experiment
timeout 120 /usr/bin/python3.11 campaign.py --snapshot automatic-expiry
/usr/sbin/poweroff
